

sub EVENT_SPAWN 
{
quest::emote ("reforms from the dust.");  
}

sub EVENT_COMBAT {

	if ($combat_state == 0) 
	{
	
	}
	
	if ($combat_state == 1) {
	quest::setnexthpevent(95);
	
	
	}

}

sub EVENT_HP {

	if ($hpevent == 95) 
	{
	quest::setnexthpevent(90);
	quest::emote("begins to crumble");
	quest::spawn2(999235,1,0,446.6,699.7,-46.9,64.1);
	quest::spawn2(999235,1,0,445.5,632.5,-46.9,34.8);
	quest::npcsize(48)
	}

	if ($hpevent == 90) {
    quest::setnexthpevent(85);
    quest::emote("begins to crumble");
	quest::spawn2(999235,1,0,446.6,699.7,-46.9,64.1);
	quest::spawn2(999235,1,0,445.5,632.5,-46.9,34.8);
	quest::npcsize(46)
	}
    
	if ($hpevent == 85) {
    quest::setnexthpevent(80);
    quest::emote("begins to crumble");
	quest::spawn2(999235,1,0,446.6,699.7,-46.9,64.1);
	quest::spawn2(999235,1,0,445.5,632.5,-46.9,34.8);
	quest::npcsize(44)
	}
	
	if ($hpevent == 80) {
    quest::setnexthpevent(75);
    quest::emote("begins to crumble");
	quest::spawn2(999235,1,0,446.6,699.7,-46.9,64.1);
	quest::spawn2(999235,1,0,445.5,632.5,-46.9,34.8);
	quest::npcsize(42)
	}
	
	if ($hpevent == 75) {
    quest::setnexthpevent(70);
    quest::emote("begins to crumble");
	quest::spawn2(999235,1,0,446.6,699.7,-46.9,64.1);
	quest::spawn2(999235,1,0,445.5,632.5,-46.9,34.8);
	quest::npcsize(40)
	}

	if ($hpevent == 70) {
    quest::setnexthpevent(65);
    quest::emote("begins to crumble");
	quest::spawn2(999235,1,0,446.6,699.7,-46.9,64.1);
	quest::spawn2(999235,1,0,445.5,632.5,-46.9,34.8);
	quest::npcsize(38)
	}
	
	if ($hpevent == 65) {
    quest::setnexthpevent(60);
    quest::emote("begins to crumble");
	quest::spawn2(999235,1,0,446.6,699.7,-46.9,64.1);
	quest::spawn2(999235,1,0,445.5,632.5,-46.9,34.8);
	quest::npcsize(36)
	}
	
	if ($hpevent == 60) {
    quest::setnexthpevent(55);
    quest::emote("begins to crumble");
	quest::spawn2(999235,1,0,446.6,699.7,-46.9,64.1);
	quest::spawn2(999235,1,0,445.5,632.5,-46.9,34.8);
	quest::npcsize(34)
	}
	
	if ($hpevent == 55) {
    quest::setnexthpevent(50);
    quest::emote("begins to crumble");
	quest::spawn2(999235,1,0,446.6,699.7,-46.9,64.1);
	quest::spawn2(999235,1,0,445.5,632.5,-46.9,34.8);
	quest::npcsize(32)
	}
	
	if ($hpevent == 50) {
    quest::setnexthpevent(45);
    quest::emote("brushes off the broken pieces");
	quest::shout("You think you have won!  Think again Mortals!");
	quest::doanim(42);
	quest::spawn2(999235,1,0,446.6,699.7,-46.9,64.1);
	quest::spawn2(999235,1,0,445.5,632.5,-46.9,34.8);
	quest::spawn2(999235,1,0);
	quest::spawn2(999235,1,0);
	quest::spawn2(999235,1,0);
	quest::spawn2(999235,1,0);
	quest::npcsize(30)
	}
	}
sub EVENT_DEATH
{
    quest::emote("Crumble into dust");
    quest::spawn2(999301,1,0,374.8,667.2,-50.8,63.4)
	return;

}


