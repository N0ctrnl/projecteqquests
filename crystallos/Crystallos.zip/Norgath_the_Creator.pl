sub EVENT_SAY {

 my $info = quest::saylink("information");
 my $new = quest::saylink("new");
 my $past = quest::saylink("past");
 my $help = quest::saylink("help");

if ($text =~/Hail/i){
plugin::Whisper ("Someday Kris will finish my coding so i can whack some players and rejoice."); 
}


}



