sub EVENT_SAY {

if ($text =~/Hail/i) { 
  quest::say ("AWAY WITH YOU MORTAL! I HAVE NO TIME FOR YOUR WHIMPERING."); 
             
}
}






